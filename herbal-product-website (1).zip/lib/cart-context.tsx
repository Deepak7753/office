"use client"

import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react"
import { createClient } from "@/lib/supabase/client"
import type { Product } from "@/lib/products"
import { products } from "@/lib/products"

export interface CartItem {
  product: Product
  quantity: number
  dbId?: string
}

interface CartContextType {
  items: CartItem[]
  addItem: (product: Product, quantity?: number) => void
  removeItem: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clearCart: () => void
  totalItems: number
  totalPrice: number
  isLoading: boolean
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) {
        setUserId(user.id)
        loadCart(user.id)
      } else {
        setIsLoading(false)
      }
    })
  }, [])

  const loadCart = async (uid: string) => {
    const supabase = createClient()
    const { data } = await supabase
      .from("cart_items")
      .select("*")
      .eq("user_id", uid)

    if (data) {
      const cartItems: CartItem[] = data
        .map((item) => {
          const product = products.find((p) => p.id === item.product_id)
          if (!product) return null
          return { product, quantity: item.quantity, dbId: item.id }
        })
        .filter(Boolean) as CartItem[]
      setItems(cartItems)
    }
    setIsLoading(false)
  }

  const addItem = useCallback(
    async (product: Product, quantity = 1) => {
      setItems((prev) => {
        const existing = prev.find((item) => item.product.id === product.id)
        if (existing) {
          return prev.map((item) =>
            item.product.id === product.id
              ? { ...item, quantity: item.quantity + quantity }
              : item
          )
        }
        return [...prev, { product, quantity }]
      })

      if (userId) {
        const supabase = createClient()
        const { data: existing } = await supabase
          .from("cart_items")
          .select("*")
          .eq("user_id", userId)
          .eq("product_id", product.id)
          .single()

        if (existing) {
          await supabase
            .from("cart_items")
            .update({ quantity: existing.quantity + quantity })
            .eq("id", existing.id)
        } else {
          await supabase
            .from("cart_items")
            .insert({ user_id: userId, product_id: product.id, quantity })
        }
      }
    },
    [userId]
  )

  const removeItem = useCallback(
    async (productId: string) => {
      setItems((prev) => prev.filter((item) => item.product.id !== productId))

      if (userId) {
        const supabase = createClient()
        await supabase
          .from("cart_items")
          .delete()
          .eq("user_id", userId)
          .eq("product_id", productId)
      }
    },
    [userId]
  )

  const updateQuantity = useCallback(
    async (productId: string, quantity: number) => {
      if (quantity <= 0) {
        removeItem(productId)
        return
      }
      setItems((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      )

      if (userId) {
        const supabase = createClient()
        await supabase
          .from("cart_items")
          .update({ quantity })
          .eq("user_id", userId)
          .eq("product_id", productId)
      }
    },
    [userId, removeItem]
  )

  const clearCart = useCallback(async () => {
    setItems([])
    if (userId) {
      const supabase = createClient()
      await supabase.from("cart_items").delete().eq("user_id", userId)
    }
  }, [userId])

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  const totalPrice = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  )

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
        isLoading,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
