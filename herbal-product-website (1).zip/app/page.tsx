"use client"

import Link from "next/link"
import {
  ArrowRight,
  Shield,
  Leaf,
  Wind,
  Heart,
  Star,
  Truck,
  BadgeCheck,
  Sprout,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ProductCard } from "@/components/product-card"
import { products } from "@/lib/products"

const featuredProducts = products.slice(0, 8)

const stats = [
  { value: "30+", label: "Herbal Products" },
  { value: "100%", label: "Organic & Pure" },
  { value: "50K+", label: "Happy Customers" },
  { value: "4.8", label: "Average Rating" },
]

const features = [
  {
    icon: Shield,
    title: "Pollution Protection",
    description:
      "Our herbal products are specifically curated to combat the harmful effects of air and water pollution on your body.",
  },
  {
    icon: Leaf,
    title: "100% Natural",
    description:
      "Every product is sourced from organic farms across India. No chemicals, no preservatives, no artificial additives.",
  },
  {
    icon: Heart,
    title: "Ayurveda Backed",
    description:
      "Each formulation is rooted in 5000-year-old Ayurvedic wisdom, validated by modern scientific research.",
  },
  {
    icon: Wind,
    title: "Respiratory Health",
    description:
      "Special range of herbs like Vasaka, Mulethi, and Tulsi to protect and heal your lungs from pollution damage.",
  },
]

const categories = [
  { name: "Immunity Boosters", icon: Shield, count: 6 },
  { name: "Detox & Cleanse", icon: Sprout, count: 5 },
  { name: "Respiratory Health", icon: Wind, count: 3 },
  { name: "Anti-Pollution", icon: Leaf, count: 4 },
]

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background">
        <div className="mx-auto max-w-7xl px-4 py-16 md:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <Badge variant="secondary" className="mb-4">
              <Leaf className="mr-1 h-3 w-3" />
              Trusted by 50,000+ customers across India
            </Badge>
            <h1 className="mb-4 text-balance font-serif text-4xl font-bold tracking-tight text-foreground md:text-6xl">
              Pure Ayurvedic Herbs for a{" "}
              <span className="text-primary">Pollution-Free</span> Life
            </h1>
            <p className="mb-8 text-pretty text-lg leading-relaxed text-muted-foreground md:text-xl">
              Shield your body from India{"'"}s growing pollution crisis with
              30+ scientifically-backed Ayurvedic herbal products. From Tulsi to
              Moringa, nature has the answer.
            </p>
            <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <Link href="/products">
                <Button size="lg" className="gap-2">
                  Shop All Products
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/calculator">
                <Button size="lg" variant="outline" className="gap-2 bg-transparent">
                  Nutrition Calculator
                </Button>
              </Link>
            </div>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-lg border bg-card p-4 text-center"
              >
                <p className="text-2xl font-bold text-primary md:text-3xl">
                  {stat.value}
                </p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why VedaHerbs */}
      <section className="border-t bg-muted/30 py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-10 text-center">
            <h2 className="mb-2 font-serif text-3xl font-bold text-foreground">
              Why VedaHerbs?
            </h2>
            <p className="text-muted-foreground">
              India faces a pollution crisis. We bring Ayurveda{"'"}s ancient
              wisdom to protect modern lives.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature) => (
              <Card key={feature.title} className="border-none bg-card shadow-sm">
                <CardContent className="flex flex-col gap-3 p-6">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <feature.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Shop by Category */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-10 text-center">
            <h2 className="mb-2 font-serif text-3xl font-bold text-foreground">
              Shop by Category
            </h2>
            <p className="text-muted-foreground">
              Find the right herbal solution for your health needs
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {categories.map((cat) => (
              <Link
                key={cat.name}
                href={`/products?category=${encodeURIComponent(cat.name)}`}
              >
                <Card className="group cursor-pointer transition-all hover:shadow-md hover:border-primary/30">
                  <CardContent className="flex items-center gap-4 p-5">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 transition-colors group-hover:bg-primary/20">
                      <cat.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{cat.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {cat.count} products
                      </p>
                    </div>
                    <ArrowRight className="ml-auto h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="border-t bg-muted/30 py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <h2 className="mb-2 font-serif text-3xl font-bold text-foreground">
                Featured Products
              </h2>
              <p className="text-muted-foreground">
                Our most popular herbal wellness products
              </p>
            </div>
            <Link href="/products" className="hidden md:block">
              <Button variant="outline" className="gap-2 bg-transparent">
                View All
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="mt-6 text-center md:hidden">
            <Link href="/products">
              <Button variant="outline" className="gap-2 bg-transparent">
                View All Products
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            <div className="flex flex-col items-center gap-2 text-center">
              <Truck className="h-8 w-8 text-primary" />
              <p className="text-sm font-semibold text-foreground">Free Delivery</p>
              <p className="text-xs text-muted-foreground">On orders above ₹499</p>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
              <BadgeCheck className="h-8 w-8 text-primary" />
              <p className="text-sm font-semibold text-foreground">Lab Tested</p>
              <p className="text-xs text-muted-foreground">Every batch verified</p>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
              <Leaf className="h-8 w-8 text-primary" />
              <p className="text-sm font-semibold text-foreground">100% Organic</p>
              <p className="text-xs text-muted-foreground">No chemicals ever</p>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
              <Star className="h-8 w-8 text-primary" />
              <p className="text-sm font-semibold text-foreground">4.8 Rating</p>
              <p className="text-xs text-muted-foreground">Across all products</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pollution CTA */}
      <section className="border-t bg-primary py-16">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <h2 className="mb-4 font-serif text-3xl font-bold text-primary-foreground">
            Pollution Is Rising. Protect Yourself Naturally.
          </h2>
          <p className="mb-6 text-primary-foreground/80 leading-relaxed">
            With AQI levels crossing 400+ in major Indian cities, your body
            needs natural protection. Our herbal products cleanse your lungs,
            purify your blood, and boost your immunity against environmental
            toxins.
          </p>
          <Link href="/products">
            <Button
              size="lg"
              variant="secondary"
              className="gap-2"
            >
              Start Your Herbal Journey
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
