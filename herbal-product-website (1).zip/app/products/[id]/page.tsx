"use client"

import { use, useState } from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import {
  ArrowLeft,
  ShoppingCart,
  Star,
  Leaf,
  Minus,
  Plus,
  Check,
  Shield,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProductCard } from "@/components/product-card"
import { getProductById, products } from "@/lib/products"
import { useCart } from "@/lib/cart-context"
import { toast } from "sonner"

const dailyValues: Record<string, number> = {
  calories: 2000,
  protein: 50,
  carbs: 300,
  fat: 65,
  fiber: 25,
  vitaminC: 90,
  iron: 18,
  calcium: 1000,
}

const nutrientLabels: Record<string, string> = {
  calories: "Calories",
  protein: "Protein",
  carbs: "Carbohydrates",
  fat: "Total Fat",
  fiber: "Dietary Fiber",
  vitaminC: "Vitamin C",
  iron: "Iron",
  calcium: "Calcium",
}

const nutrientUnits: Record<string, string> = {
  calories: "kcal",
  protein: "g",
  carbs: "g",
  fat: "g",
  fiber: "g",
  vitaminC: "mg",
  iron: "mg",
  calcium: "mg",
}

export default function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const product = getProductById(id)
  const { addItem } = useCart()
  const [quantity, setQuantity] = useState(1)

  if (!product) {
    notFound()
  }

  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  )

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4)

  const handleAddToCart = () => {
    addItem(product, quantity)
    toast.success(`${quantity}x ${product.name} added to cart`)
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <Link href="/products">
        <Button variant="ghost" size="sm" className="mb-6 gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Products
        </Button>
      </Link>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Product Image */}
        <div className="relative aspect-square overflow-hidden rounded-xl border bg-muted">
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
            <div className="text-center">
              <span className="block text-8xl font-bold text-primary/20">
                {product.hindiName.charAt(0)}
              </span>
              <span className="mt-2 block text-lg text-primary/40">
                {product.hindiName}
              </span>
            </div>
          </div>
          {discount > 0 && (
            <Badge className="absolute left-4 top-4 bg-accent text-accent-foreground text-sm px-3 py-1">
              {discount}% OFF
            </Badge>
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col gap-4">
          <div>
            <Badge variant="secondary" className="mb-2">
              {product.category}
            </Badge>
            <h1 className="font-serif text-3xl font-bold text-foreground">
              {product.name}
            </h1>
            <p className="mt-1 text-lg text-muted-foreground">
              {product.hindiName}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(product.rating)
                      ? "fill-accent text-accent"
                      : "text-muted"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm font-medium text-foreground">{product.rating}</span>
            <span className="text-sm text-muted-foreground">
              ({product.reviews} reviews)
            </span>
          </div>

          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-bold text-foreground">
              {"₹"}{product.price}
            </span>
            <span className="text-lg text-muted-foreground line-through">
              {"₹"}{product.originalPrice}
            </span>
            <Badge className="bg-accent text-accent-foreground">Save {"₹"}{product.originalPrice - product.price}</Badge>
          </div>

          <Separator />

          <p className="leading-relaxed text-muted-foreground">
            {product.description}
          </p>

          <div>
            <h3 className="mb-2 font-semibold text-foreground">Key Benefits</h3>
            <ul className="flex flex-col gap-2">
              {product.benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                  <span className="text-sm text-foreground">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          <Separator />

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-lg border">
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-8 text-center font-medium text-foreground">
                {quantity}
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10"
                onClick={() => setQuantity(quantity + 1)}
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <Button className="flex-1 gap-2" size="lg" onClick={handleAddToCart}>
              <ShoppingCart className="h-4 w-4" />
              Add to Cart - {"₹"}{product.price * quantity}
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2 rounded-lg border p-3">
              <Leaf className="h-4 w-4 text-primary" />
              <span className="text-xs text-foreground">100% Organic</span>
            </div>
            <div className="flex items-center gap-2 rounded-lg border p-3">
              <Shield className="h-4 w-4 text-primary" />
              <span className="text-xs text-foreground">Lab Tested</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-12">
        <Tabs defaultValue="nutrition">
          <TabsList>
            <TabsTrigger value="nutrition">Nutrition Facts</TabsTrigger>
            <TabsTrigger value="usage">How to Use</TabsTrigger>
          </TabsList>
          <TabsContent value="nutrition" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  Nutrition Facts per Serving ({product.servingSize})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  {Object.entries(product.nutrition).map(([key, value]) => {
                    const dvKey = key as keyof typeof dailyValues
                    const pct = Math.min(
                      (value / dailyValues[dvKey]) * 100,
                      100
                    )
                    return (
                      <div key={key} className="flex flex-col gap-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-foreground">
                            {nutrientLabels[key]}
                          </span>
                          <span className="text-sm text-foreground">
                            {value} {nutrientUnits[key]}{" "}
                            <span className="text-xs text-muted-foreground">
                              ({pct.toFixed(0)}% DV)
                            </span>
                          </span>
                        </div>
                        <Progress value={pct} className="h-2" />
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="usage" className="mt-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col gap-4">
                  <div>
                    <h4 className="mb-1 font-semibold text-foreground">Recommended Dosage</h4>
                    <p className="text-sm text-muted-foreground">
                      {product.servingSize} mixed with warm water or milk, 1-2
                      times daily, preferably on an empty stomach or as directed
                      by your Ayurvedic practitioner.
                    </p>
                  </div>
                  <div>
                    <h4 className="mb-1 font-semibold text-foreground">Storage</h4>
                    <p className="text-sm text-muted-foreground">
                      Store in a cool, dry place away from direct sunlight. Keep
                      the lid tightly closed after use. Best consumed within 6
                      months of opening.
                    </p>
                  </div>
                  <div>
                    <h4 className="mb-1 font-semibold text-foreground">Precautions</h4>
                    <p className="text-sm text-muted-foreground">
                      Consult your doctor if you are pregnant, nursing, or taking
                      medication. Not intended for children under 12 years. Do
                      not exceed the recommended dosage.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="mb-6 font-serif text-2xl font-bold text-foreground">
            Related Products
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
