"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Package, ArrowRight, Clock, CheckCircle, Truck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"

interface OrderItem {
  productId: string
  name: string
  price: number
  quantity: number
}

interface Order {
  id: string
  items: OrderItem[]
  total: number
  status: string
  shipping_address: string
  phone: string
  created_at: string
}

const statusConfig: Record<string, { icon: typeof Clock; label: string; variant: "default" | "secondary" | "outline" }> = {
  pending: { icon: Clock, label: "Pending", variant: "secondary" },
  confirmed: { icon: CheckCircle, label: "Confirmed", variant: "default" },
  shipped: { icon: Truck, label: "Shipped", variant: "default" },
  delivered: { icon: Package, label: "Delivered", variant: "outline" },
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchOrders = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from("orders")
        .select("*")
        .order("created_at", { ascending: false })

      if (data) {
        setOrders(data as Order[])
      }
      setIsLoading(false)
    }
    fetchOrders()
  }, [])

  if (isLoading) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <p className="text-muted-foreground">Loading orders...</p>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold text-foreground">
        My Orders
      </h1>

      {orders.length === 0 ? (
        <div className="flex flex-col items-center gap-4 py-16 text-center">
          <Package className="h-16 w-16 text-muted-foreground" />
          <h2 className="text-xl font-semibold text-foreground">No orders yet</h2>
          <p className="text-muted-foreground">
            Start your herbal wellness journey by placing your first order.
          </p>
          <Link href="/products">
            <Button className="gap-2">
              Browse Products
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {orders.map((order) => {
            const config = statusConfig[order.status] || statusConfig.pending
            const StatusIcon = config.icon
            return (
              <Card key={order.id}>
                <CardHeader className="flex flex-row items-center justify-between pb-3">
                  <div>
                    <CardTitle className="text-base">
                      Order #{order.id.slice(0, 8).toUpperCase()}
                    </CardTitle>
                    <p className="text-xs text-muted-foreground">
                      {new Date(order.created_at).toLocaleDateString("en-IN", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <Badge variant={config.variant} className="gap-1">
                    <StatusIcon className="h-3 w-3" />
                    {config.label}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col gap-2">
                    {(order.items as OrderItem[]).map((item, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between text-sm"
                      >
                        <span className="text-foreground">
                          {item.name} x{item.quantity}
                        </span>
                        <span className="text-muted-foreground">
                          {"₹"}{item.price * item.quantity}
                        </span>
                      </div>
                    ))}
                    <div className="mt-2 flex items-center justify-between border-t pt-2 font-semibold">
                      <span className="text-foreground">Total</span>
                      <span className="text-foreground">{"₹"}{order.total}</span>
                    </div>
                    {order.shipping_address && (
                      <p className="mt-1 text-xs text-muted-foreground">
                        Delivering to: {order.shipping_address}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
