import {
  Leaf,
  Heart,
  Shield,
  FlaskConical,
  Users,
  Mountain,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const values = [
  {
    icon: Leaf,
    title: "100% Organic",
    description:
      "Every product is sourced from certified organic farms across India. We never use pesticides, chemicals, or synthetic additives.",
  },
  {
    icon: FlaskConical,
    title: "Lab Tested",
    description:
      "Each batch undergoes rigorous third-party lab testing for purity, potency, and absence of heavy metals and contaminants.",
  },
  {
    icon: Heart,
    title: "Ayurveda First",
    description:
      "Our formulations are rooted in 5,000 years of Ayurvedic wisdom, combining ancient knowledge with modern quality standards.",
  },
  {
    icon: Shield,
    title: "Anti-Pollution Focus",
    description:
      "We specifically curate herbs that combat the damaging effects of air pollution, water contamination, and environmental toxins.",
  },
  {
    icon: Users,
    title: "Community Sourced",
    description:
      "We partner directly with 200+ tribal and rural farming families across India, ensuring fair trade and sustainable practices.",
  },
  {
    icon: Mountain,
    title: "Himalayan Heritage",
    description:
      "Many of our rare herbs are wild-harvested from the pristine Himalayan foothills, ensuring the highest potency and purity.",
  },
]

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-b from-primary/5 to-background py-16">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <h1 className="mb-4 font-serif text-4xl font-bold text-foreground md:text-5xl">
            About VedaHerbs
          </h1>
          <p className="text-lg leading-relaxed text-muted-foreground">
            Born from the realization that India{"'"}s pollution crisis demands
            a natural response, VedaHerbs brings you the purest Ayurvedic
            herbal products to protect and restore your health.
          </p>
        </div>
      </section>

      {/* Mission */}
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-4">
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <h2 className="mb-4 font-serif text-2xl font-bold text-foreground">
                Our Mission
              </h2>
              <p className="mb-4 leading-relaxed text-muted-foreground">
                India faces an unprecedented pollution crisis. With AQI levels
                consistently above 400 in major cities, millions suffer from
                respiratory diseases, weakened immunity, and toxin buildup in
                their bodies.
              </p>
              <p className="leading-relaxed text-muted-foreground">
                At VedaHerbs, we believe that nature has always had the answer.
                For thousands of years, Ayurvedic herbs like Tulsi, Neem,
                Moringa, and Giloy have protected Indian families from disease
                and environmental harm. We are bringing this ancient wisdom to
                the modern world with scientific rigor and uncompromising
                quality.
              </p>
            </div>
            <div>
              <h2 className="mb-4 font-serif text-2xl font-bold text-foreground">
                The Problem We Solve
              </h2>
              <ul className="flex flex-col gap-3">
                {[
                  "Air pollution in Delhi NCR, Mumbai, and other cities at dangerous levels year-round",
                  "7 out of 10 most polluted cities in the world are in India",
                  "1.67 million deaths attributed to air pollution in India annually",
                  "Contaminated water and food supply weakening immunity nationwide",
                  "Modern medicine treats symptoms, Ayurveda addresses the root cause",
                ].map((item) => (
                  <li key={item} className="flex gap-2 text-sm text-muted-foreground">
                    <Shield className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="border-t bg-muted/30 py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-10 text-center">
            <h2 className="mb-2 font-serif text-3xl font-bold text-foreground">
              Our Values
            </h2>
            <p className="text-muted-foreground">
              What makes VedaHerbs different from every other supplement brand
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {values.map((value) => (
              <Card key={value.title}>
                <CardContent className="flex flex-col gap-3 p-6">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <value.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{value.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-4">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {[
              { value: "30+", label: "Herbal Products" },
              { value: "200+", label: "Farming Partners" },
              { value: "50K+", label: "Happy Customers" },
              { value: "15+", label: "States Served" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl font-bold text-primary">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
