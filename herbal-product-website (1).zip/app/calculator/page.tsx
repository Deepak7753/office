import { NutritionCalculator } from "@/components/nutrition-calculator"

export default function CalculatorPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2 font-serif text-3xl font-bold text-foreground">
          Herbal Nutrition Calculator
        </h1>
        <p className="text-muted-foreground">
          Select multiple herbal products and calculate your combined daily
          nutrition intake. See how each herb contributes to your recommended
          daily values.
        </p>
      </div>
      <NutritionCalculator />
    </div>
  )
}
