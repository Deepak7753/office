import { CheckCircle, Leaf } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-[80vh] w-full items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center gap-2">
          <Leaf className="h-10 w-10 text-primary" />
        </div>
        <Card>
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <CheckCircle className="h-16 w-16 text-primary" />
            <h1 className="font-serif text-2xl font-bold text-foreground">
              Account Created Successfully!
            </h1>
            <p className="leading-relaxed text-muted-foreground">
              We have sent a confirmation email to your inbox. Please check your
              email and click the verification link to activate your account.
            </p>
            <Link href="/auth/login">
              <Button className="mt-2">Go to Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
