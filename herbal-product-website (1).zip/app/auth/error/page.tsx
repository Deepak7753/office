import { AlertCircle, Leaf } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function AuthErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ error: string }>
}) {
  const params = await searchParams

  return (
    <div className="flex min-h-[80vh] w-full items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center gap-2">
          <Leaf className="h-10 w-10 text-primary" />
        </div>
        <Card>
          <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
            <AlertCircle className="h-16 w-16 text-destructive" />
            <h1 className="font-serif text-2xl font-bold text-foreground">
              Authentication Error
            </h1>
            <p className="leading-relaxed text-muted-foreground">
              {params?.error
                ? `Error: ${params.error}`
                : "Something went wrong during authentication. Please try again."}
            </p>
            <div className="flex gap-3">
              <Link href="/auth/login">
                <Button>Try Again</Button>
              </Link>
              <Link href="/">
                <Button variant="outline">Go Home</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
