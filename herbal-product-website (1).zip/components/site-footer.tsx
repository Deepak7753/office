import Link from "next/link"
import { Leaf } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="flex flex-col gap-3">
            <Link href="/" className="flex items-center gap-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold text-foreground">VedaHerbs</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Pure Ayurvedic herbal products to protect your health from
              pollution and modern lifestyle challenges.
            </p>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Shop</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li><Link href="/products" className="transition-colors hover:text-foreground">All Products</Link></li>
              <li><Link href="/products?category=Immunity+Boosters" className="transition-colors hover:text-foreground">Immunity Boosters</Link></li>
              <li><Link href="/products?category=Detox+%26+Cleanse" className="transition-colors hover:text-foreground">Detox & Cleanse</Link></li>
              <li><Link href="/products?category=Anti-Pollution" className="transition-colors hover:text-foreground">Anti-Pollution</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Tools</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li><Link href="/calculator" className="transition-colors hover:text-foreground">Nutrition Calculator</Link></li>
              <li><Link href="/about" className="transition-colors hover:text-foreground">About Us</Link></li>
              <li><Link href="/products" className="transition-colors hover:text-foreground">Product Catalog</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold text-foreground">Account</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li><Link href="/auth/login" className="transition-colors hover:text-foreground">Login</Link></li>
              <li><Link href="/auth/sign-up" className="transition-colors hover:text-foreground">Sign Up</Link></li>
              <li><Link href="/orders" className="transition-colors hover:text-foreground">My Orders</Link></li>
              <li><Link href="/cart" className="transition-colors hover:text-foreground">Cart</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t pt-6 text-center text-sm text-muted-foreground">
          <p>VedaHerbs - Pure Ayurvedic Wellness. All products are 100% natural and organic.</p>
        </div>
      </div>
    </footer>
  )
}
