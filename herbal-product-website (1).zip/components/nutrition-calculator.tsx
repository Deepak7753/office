"use client"

import { useState } from "react"
import { Plus, X, Calculator, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { products, type Product } from "@/lib/products"

interface SelectedProduct {
  product: Product
  servings: number
}

const dailyValues = {
  calories: 2000,
  protein: 50,
  carbs: 300,
  fat: 65,
  fiber: 25,
  vitaminC: 90,
  iron: 18,
  calcium: 1000,
}

const nutrientLabels: Record<string, string> = {
  calories: "Calories",
  protein: "Protein",
  carbs: "Carbs",
  fat: "Fat",
  fiber: "Fiber",
  vitaminC: "Vitamin C",
  iron: "Iron",
  calcium: "Calcium",
}

const nutrientUnits: Record<string, string> = {
  calories: "kcal",
  protein: "g",
  carbs: "g",
  fat: "g",
  fiber: "g",
  vitaminC: "mg",
  iron: "mg",
  calcium: "mg",
}

export function NutritionCalculator() {
  const [selectedProducts, setSelectedProducts] = useState<SelectedProduct[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [showDropdown, setShowDropdown] = useState(false)

  const filteredProducts = products.filter(
    (p) =>
      (p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.hindiName.includes(searchQuery)) &&
      !selectedProducts.find((sp) => sp.product.id === p.id) &&
      p.nutrition.calories > 0
  )

  const addProduct = (product: Product) => {
    setSelectedProducts((prev) => [...prev, { product, servings: 1 }])
    setSearchQuery("")
    setShowDropdown(false)
  }

  const removeProduct = (productId: string) => {
    setSelectedProducts((prev) =>
      prev.filter((sp) => sp.product.id !== productId)
    )
  }

  const updateServings = (productId: string, servings: number) => {
    if (servings < 0.5) return
    setSelectedProducts((prev) =>
      prev.map((sp) =>
        sp.product.id === productId ? { ...sp, servings } : sp
      )
    )
  }

  const totals = selectedProducts.reduce(
    (acc, { product, servings }) => ({
      calories: acc.calories + product.nutrition.calories * servings,
      protein: acc.protein + product.nutrition.protein * servings,
      carbs: acc.carbs + product.nutrition.carbs * servings,
      fat: acc.fat + product.nutrition.fat * servings,
      fiber: acc.fiber + product.nutrition.fiber * servings,
      vitaminC: acc.vitaminC + product.nutrition.vitaminC * servings,
      iron: acc.iron + product.nutrition.iron * servings,
      calcium: acc.calcium + product.nutrition.calcium * servings,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, vitaminC: 0, iron: 0, calcium: 0 }
  )

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Calculator className="h-5 w-5 text-primary" />
              Select Herbal Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Label htmlFor="search-herbs" className="sr-only">Search herbs</Label>
              <Input
                id="search-herbs"
                placeholder="Search herbs (e.g., Tulsi, Neem, Moringa...)"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value)
                  setShowDropdown(true)
                }}
                onFocus={() => setShowDropdown(true)}
              />
              {showDropdown && searchQuery && filteredProducts.length > 0 && (
                <div className="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-md border bg-popover p-1 shadow-md">
                  {filteredProducts.slice(0, 8).map((product) => (
                    <button
                      key={product.id}
                      type="button"
                      className="flex w-full items-center gap-2 rounded px-3 py-2 text-left text-sm hover:bg-muted transition-colors"
                      onClick={() => addProduct(product)}
                    >
                      <Leaf className="h-3.5 w-3.5 text-primary" />
                      <span className="font-medium text-foreground">{product.name}</span>
                      <span className="text-xs text-muted-foreground">({product.hindiName})</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {selectedProducts.length === 0 ? (
              <div className="mt-6 flex flex-col items-center gap-2 rounded-lg border-2 border-dashed p-8 text-center">
                <Plus className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Search and add herbal products to calculate their combined nutrition
                </p>
              </div>
            ) : (
              <div className="mt-4 flex flex-col gap-3">
                {selectedProducts.map(({ product, servings }) => (
                  <div
                    key={product.id}
                    className="flex items-center gap-3 rounded-lg border p-3"
                  >
                    <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-md bg-primary/10">
                      <Leaf className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-foreground">
                        {product.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {product.servingSize} per serving
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7 bg-transparent"
                        onClick={() => updateServings(product.id, servings - 0.5)}
                        aria-label="Decrease servings"
                      >
                        -
                      </Button>
                      <span className="w-8 text-center text-sm font-medium text-foreground">
                        {servings}
                      </span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7 bg-transparent"
                        onClick={() => updateServings(product.id, servings + 0.5)}
                        aria-label="Increase servings"
                      >
                        +
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-muted-foreground hover:text-destructive"
                        onClick={() => removeProduct(product.id)}
                        aria-label="Remove product"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {selectedProducts.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Per-Product Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="pb-2 text-left font-medium text-muted-foreground">Product</th>
                      <th className="pb-2 text-right font-medium text-muted-foreground">Cal</th>
                      <th className="pb-2 text-right font-medium text-muted-foreground">Protein</th>
                      <th className="pb-2 text-right font-medium text-muted-foreground">Vit C</th>
                      <th className="pb-2 text-right font-medium text-muted-foreground">Iron</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedProducts.map(({ product, servings }) => (
                      <tr key={product.id} className="border-b last:border-0">
                        <td className="py-2 text-foreground">{product.name.split(" ")[0]}</td>
                        <td className="py-2 text-right text-foreground">
                          {(product.nutrition.calories * servings).toFixed(1)}
                        </td>
                        <td className="py-2 text-right text-foreground">
                          {(product.nutrition.protein * servings).toFixed(1)}g
                        </td>
                        <td className="py-2 text-right text-foreground">
                          {(product.nutrition.vitaminC * servings).toFixed(1)}mg
                        </td>
                        <td className="py-2 text-right text-foreground">
                          {(product.nutrition.iron * servings).toFixed(1)}mg
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div>
        <Card className="sticky top-20">
          <CardHeader>
            <CardTitle className="text-lg">Total Nutrition Summary</CardTitle>
            <p className="text-sm text-muted-foreground">
              {selectedProducts.length > 0
                ? `Based on ${selectedProducts.length} product${selectedProducts.length > 1 ? "s" : ""}`
                : "Add products to see nutrition breakdown"}
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              {Object.entries(totals).map(([key, value]) => {
                const dvKey = key as keyof typeof dailyValues
                const percentage = Math.min(
                  (value / dailyValues[dvKey]) * 100,
                  100
                )
                return (
                  <div key={key} className="flex flex-col gap-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">
                        {nutrientLabels[key]}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-foreground">
                          {value.toFixed(1)} {nutrientUnits[key]}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {percentage.toFixed(0)}% DV
                        </Badge>
                      </div>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                )
              })}
            </div>

            {selectedProducts.length > 0 && (
              <div className="mt-6 rounded-lg bg-primary/5 p-4">
                <h4 className="mb-2 text-sm font-semibold text-foreground">
                  Health Insight
                </h4>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {totals.vitaminC > 50
                    ? "Excellent Vitamin C intake! This combination provides strong antioxidant protection against air pollution and free radicals."
                    : totals.iron > 5
                      ? "Great iron content! This herbal combination supports healthy blood oxygen levels, crucial for people in polluted areas."
                      : totals.protein > 5
                        ? "Good plant protein intake! These herbs provide essential amino acids for cellular repair from pollution damage."
                        : "Add more herbs to increase your daily nutrient intake. Consider Moringa or Amla for a nutritional boost."}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
