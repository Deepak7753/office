"use client"

import React from "react"

import Link from "next/link"
import { Star, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Product } from "@/lib/products"
import { useCart } from "@/lib/cart-context"
import { toast } from "sonner"

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart()
  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  )

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    addItem(product)
    toast.success(`${product.name} added to cart`)
  }

  return (
    <Link href={`/products/${product.id}`}>
      <Card className="group h-full overflow-hidden transition-all hover:shadow-lg hover:border-primary/30">
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
            <span className="text-5xl font-bold text-primary/20">
              {product.hindiName.charAt(0)}
            </span>
          </div>
          {discount > 0 && (
            <Badge className="absolute left-2 top-2 bg-accent text-accent-foreground">
              {discount}% OFF
            </Badge>
          )}
        </div>
        <CardContent className="flex flex-col gap-2 p-4">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h3 className="truncate text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                {product.name}
              </h3>
              <p className="text-xs text-muted-foreground">{product.hindiName}</p>
            </div>
          </div>
          <Badge variant="secondary" className="w-fit text-xs">
            {product.category}
          </Badge>
          <div className="flex items-center gap-1">
            <Star className="h-3.5 w-3.5 fill-accent text-accent" />
            <span className="text-xs font-medium text-foreground">{product.rating}</span>
            <span className="text-xs text-muted-foreground">({product.reviews})</span>
          </div>
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-foreground">
                {"₹"}{product.price}
              </span>
              <span className="text-xs text-muted-foreground line-through">
                {"₹"}{product.originalPrice}
              </span>
            </div>
            <Button
              size="sm"
              className="h-8 gap-1 text-xs"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="h-3 w-3" />
              Add
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
