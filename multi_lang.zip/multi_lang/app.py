from flask import Flask, render_template, request, jsonify
from deep_translator import GoogleTranslator
from langdetect import detect, DetectorFactory
import os

# Ensure consistent results for language detection
DetectorFactory.seed = 0

app = Flask(__name__)

# Supported languages mapping for deep-translator
LANGUAGES = {
    'en': 'english',
    'hi': 'hindi',
    'es': 'spanish',
    'fr': 'french',
    'de': 'german',
    'zh-CN': 'chinese (simplified)',
    'ja': 'japanese',
    'ar': 'arabic',
    'ru': 'russian',
    'pt': 'portuguese'
}

@app.route('/')
def index():
    return render_template('index.html', languages=LANGUAGES)

@app.route('/translate', methods=['POST'])
def translate_text():
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text.strip():
            return jsonify({'error': 'No text provided'}), 400
        
        results = {}
        # We translate sequentially (for production, consider threading or a paid API)
        for code, name in LANGUAGES.items():
            try:
                translated = GoogleTranslator(source='auto', target=code).translate(text)
                results[code] = {
                    'name': name.capitalize(),
                    'text': translated
                }
            except Exception as e:
                results[code] = {
                    'name': name.capitalize(),
                    'text': "[Error in translation]"
                }
        
        return jsonify({'translations': results})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/detect', methods=['POST'])
def detect_language():
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text.strip():
            return jsonify({'error': 'No text provided'}), 400
        
        lang_code = detect(text)
        # Try to find the full name from our dict, or return code
        lang_name = LANGUAGES.get(lang_code, lang_code).capitalize()
        
        return jsonify({
            'language': lang_name,
            'code': lang_code
        })
    
    except Exception as e:
        return jsonify({'error': "Could not detect language"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)